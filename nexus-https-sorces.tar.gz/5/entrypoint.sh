#!/usr/bin/env bash

# Sonatype Nexus3 Docker Image variables defined:
#
# NEXUS_DATA=/nexus-data
# NEXUS_HOME=/opt/sonatype/nexus
# NEXUS_SSL=/opt/sonatype/nexus/etc/ssl
#
set -x
set -eo pipefail

# Reinstall CA bundle
#/usr/bin/microdnf -y reinstall ca-certificates

# Define variables
[ ${#NEXUS_DATA} -eq 0 ] && NEXUS_DATA='/nexus-data'
[ ${#NEXUS_SSL} -eq 0 ] && NEXUS_SSL='/opt/sonatype/nexus/etc/ssl'
[ ${#PUBLIC_CERT} -eq 0 ] && PUBLIC_CERT="${NEXUS_SSL}/fullchain.pem"
[ ${#PRIVATE_KEY} -eq 0 ] && PRIVATE_KEY="${NEXUS_SSL}/key.pem"
[ ${#PRIVATE_KEY_PASSWORD} -eq 0 ] && PRIVATE_KEY_PASSWORD='nexus-https'

# Define .userPrefs folder
mkdir -p ${NEXUS_HOME}/.java && chown nexus:nexus ${NEXUS_HOME}/.java
echo "-Djava.util.prefs.userRoot=${NEXUS_HOME}" >> ${NEXUS_HOME}/bin/nexus.vmoptions

if [ "$1" == 'bin/nexus' ]; then
 if [ `find "${NEXUS_SSL}" -type f 2>/dev/null | wc -l` -ge 2 ]; then
  if [ ! -f "${PUBLIC_CERT}" ]; then echo "Fullchain certificate file \"${PUBLIC_CERT}\" is not found!"; exit 1; fi
  if [ ! -f "${PRIVATE_KEY}" ]; then echo "Private key file \"${PRIVATE_KEY}\" is not found!"; exit 1; fi
   sum1=$(openssl x509 -pubkey -in "${PUBLIC_CERT}" -noout | openssl md5 | tail -n 1 | awk '{print $NF}')
   sum2=$(openssl pkey -pubout -in "${PRIVATE_KEY}" | openssl md5 | tail -n 1 | awk '{print $NF}')
  if [ "$sum1" == "$sum2" ]; then
   rm -f "${NEXUS_SSL}"/jetty.key 2>/dev/null
   openssl pkcs12 -export -in "${PUBLIC_CERT}" -inkey "${PRIVATE_KEY}" -out "${NEXUS_SSL}"/jetty.key -passout pass:${PRIVATE_KEY_PASSWORD}
   kt=`which keytool`
   if [ ${#kt} -ne 0 ]; then
    rm -f "${NEXUS_SSL}"/keystore.jks 2>/dev/null
    ${kt} -importkeystore -noprompt -deststorepass ${PRIVATE_KEY_PASSWORD} -destkeypass ${PRIVATE_KEY_PASSWORD} -destkeystore "${NEXUS_SSL}"/keystore.jks -deststoretype pkcs12 -srckeystore "${NEXUS_SSL}"/jetty.key -srcstoretype PKCS12 -srcstorepass ${PRIVATE_KEY_PASSWORD}
    sed -r '/<Set name="(KeyStore|KeyManager|TrustStore)Password">/ s:>.*$:>'${PRIVATE_KEY_PASSWORD}'</Set>:' -i "${NEXUS_HOME}"/etc/jetty/jetty-https.xml
    [ ! -d "${NEXUS_DATA}" ] && mkdir -p "${NEXUS_DATA}"
    chown -R nexus:nexus "${NEXUS_DATA}"
    exec gosu nexus "$@"
   else
    echo "There is no 'keytool' utility. Check that JDK >=1.8 has been installed!"
    exit 1
   fi
  else
   echo "The fullchain certificate file: ${PUBLIC_CERT}"
   echo "does not matches with the private key file: ${PRIVATE_KEY}"
   exit 1
  fi
 else
  echo "Folder \"${NEXUS_SSL}\" not found or does not contains SSL-certificate and key files. Stop working!"
  exit 1
 fi
fi

exec "$@"
